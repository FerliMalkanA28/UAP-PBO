package uappbo;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ProdukInputController {

   @FXML 
   private Button btnFood;
   
   @FXML
   private Button btnProduct;
   
   @FXML
   private Button btnBack;
   
   @FXML
   public void makanInp (ActionEvent event) throws IOException{
       FXMLLoader loader = new FXMLLoader(getClass().getResource("makananInput.fxml"));
       Parent root = (Parent) loader.load();
       Stage stage = (Stage) btnFood.getScene().getWindow();
       stage.setScene(new Scene(root));
   }
   
   @FXML
   public void barangIpt (ActionEvent event) throws IOException{
    FXMLLoader loader = new FXMLLoader(getClass().getResource("barangInput.fxml"));
       Parent root = (Parent) loader.load();
       Stage stage = (Stage) btnProduct.getScene().getWindow();
       stage.setScene(new Scene(root));
   }
   
   @FXML
   public void kembali (ActionEvent event) throws IOException{       
       FXMLLoader loader = new FXMLLoader(getClass().getResource("home.fxml"));
       Parent root = (Parent) loader.load();
       Stage stage = (Stage) btnBack.getScene().getWindow();
       stage.setScene(new Scene(root));
   }
   
}
