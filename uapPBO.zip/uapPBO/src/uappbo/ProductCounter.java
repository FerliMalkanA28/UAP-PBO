package uappbo;

public interface ProductCounter {
    public final double TAX = 0.2;
 
    public int hitungJumlahProduk();
    
    public int hitungHargaProduk();
}
